package com.demo.test;
import java.util.*;

import com.demo.beans.Array;

public class TestArray {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
      Array ob=new Array();
      for(int i=0;i<ob.getLength();i++) {
    	  System.out.println("enter the number");
    	  int n=sc.nextInt();
    	  ob.add();
      }
	}

}
