package com.demo.test;

import com.demo.trees.BinarySearchTree;

public class TestBinarySearchTree 
{

	public static void main(String[] args) 
	{
	   BinarySearchTree obj=new BinarySearchTree();
	  
	   int[] arr = {10,7,15,5,8,3,6,12,17,18,11};
	   
	   for(int i=0; i<arr.length; i++)
	   {
		   obj.insertNode(arr[i]);
	   }
	   
	   obj.inorder();
	   obj.preorder();
	   obj.postorder();
	   
	   System.out.println("key is found : "+obj.search(5));
	 
	   System.out.println(obj.searchRecursive(19));
	   
	   System.out.println(" ================================================ ");
	   
	   System.out.println(obj.searchNonRecursive(28));
	}

}
