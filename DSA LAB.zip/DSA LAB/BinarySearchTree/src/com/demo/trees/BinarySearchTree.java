package com.demo.trees;

public class BinarySearchTree 
{
	public Node root;
	class Node
	{
		int data;
		Node left;
		Node right;
		
		public Node(int value)
		{
			this.data = value;
			this.left = null;
			this.right = null;
			
		}
	}
	public BinarySearchTree()
	{
		root=null;
	}
	
	//insert node
	public void insertNode(int key)
	{
		root = insertData(root, key);
	}
	
	//insert data into the node
	public Node insertData(Node root, int key)
	{
		Node newNode = new Node(key);
		
		if(root == null)
		{
			root = newNode;
			return root;
		}
		else
		{
			if(key < root.data)
			{
				root.left = insertData(root.left, key);
			}
			else
			{
				root.right = insertData(root.right, key);
			}
			return root;
		}
	}

   //inorder
	public void inorder()
	{
		inorderTraversal(root);
		System.out.println();	
	}

	private void inorderTraversal(Node root)
	{
	     if(root!=null)
	     {
	    	 inorderTraversal(root.left);
	    	 System.out.print(root.data  + " , ");
	    	 inorderTraversal(root.right);
	     }
		
	}

	//preorder
	 public void preorder()
	 {
		 preorderTraversal(root);
	     System.out.println();	 
	 }

	private void preorderTraversal(Node root) {
		
		if(root!=null) 
		{
			System.out.print(root.data  + " , ");
			preorderTraversal(root.left);
			preorderTraversal(root.right);
		}
	}

	//postorder
	public void postorder()
	{
		postorderTraversal(root);
		System.out.println();
	}

	private void postorderTraversal(Node root) 
	{ 
		   if(root!=null)
		   {
			   postorderTraversal(root.left);
			   postorderTraversal(root.right);
			   System.out.print(root.data + " , ");
		   }   
	}
	
	//search the elements
	public boolean search(int key)
	{
		return searchBinaryTreeR(root, key);
	}

	
	//Recursive
	public boolean searchRecursive(int key)
	{
		return searchBinaryTreeR(root, key);
	}
	
	private boolean searchBinaryTreeR(Node root, int key) 
	{
		if(root!=null)
		{
			if(root.data == key)
			{
				System.out.println("data is found");
				return true;
			}
			
			else
			{
				if(root.data < key)
				{
					return searchBinaryTreeR(root.right, key);
				}
				else
				{
					return searchBinaryTreeR(root.left, key);
				}
			}
		}
		
		return false;
	}
	
	//Non-recursive
	public boolean searchNonRecursive(int key)
	{
		return searchBinaryTreeNR(root, key);
	}

	private boolean searchBinaryTreeNR(Node root, int key)
	{
		if(root!= null)
		{
			Node temp = root;
			
			while(temp != null)
			{
				if(temp.data == key)
				{
					return true;
				}
				else if(temp.data < key)
				{
					temp = temp.right;
				}
				else
				{
					temp = temp.left;
				}
			}
		}
		return false;
	}	
	
}
