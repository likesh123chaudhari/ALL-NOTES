package com.demo.graphs;

import java.util.Arrays;
import java.util.Scanner;
import com.demo.graphs.MyStackListGeneric;


public class AdjacencyList 
{
	
	Node[] heads;
	
	class Node
	{
		int data;
		Node next;
		
		public Node(int v)
		{
			this.data = v;
			this.next = null;
		}
	}
	
	public AdjacencyList(int v)
	{
		heads = new Node[v];
	}
	
	//add graph
	public void addGraph()
	{
		Scanner sc = new Scanner(System.in);
		for(int i=0; i<heads.length; i++) 
		{
			for(int j=0; j<heads.length; j++)
			{
				System.out.println("edge "+i+"--->"+j+" : ");
				int num = sc.nextInt();
				
				if(num==1)
				{
					Node newNode = new Node(j);
					
					if(heads[i] == null)
					{
						heads[i] = newNode;
					}
					else
					{
						newNode.next = heads[i];
						heads[i] = newNode;
					}
				}
			}
		}
	}
	
	//display data
	public void displayData()
	{
		for(int i =0; i<heads.length; i++)
		{
			System.out.print("Node:"+i+"------>");
			
			Node temp = heads[i];
			
			while(temp != null)
			{
				System.out.print(temp.data+"------>");
				temp = temp.next;
			}
			System.out.print("null\n");
		}
	}
	
	
	public void dfsTraversal(int n)
	{
		
		MyStackListGeneric<Integer> slist = new MyStackListGeneric<Integer>();
		
		
		//create boolean array
		boolean[] visited = new boolean[heads.length];
		
		slist.push(n);
		
		int[] mydfs = new int[heads.length];
		
		for(int i=0; i<visited.length; i++)
		{
			visited[i] = false;
		}
		
		
		int count = 0;
		while(!slist.isEmpty()) 
		{
			int d = slist.pop();
			
			if(!visited[d])
			{
				visited[d] = true; //mark it as visited
				
				mydfs[count] = d;
				count++;
				
				Node temp = heads[d];
				
				while(temp != null)
				{
					//push all non visited data in stack
					if(!visited[temp.data]) 
					{
						slist.push(temp.data); 
					}
					temp = temp.next;
				}
			}
			slist.displayData();
			System.out.println("---------------------------------");
			
		}
		System.out.println(Arrays.toString(mydfs));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
