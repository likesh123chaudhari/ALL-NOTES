package com.demo.graphs;

public class MyStackListGeneric <T>{
	
	Node top;
	class Node
	{
		T  data;
		Node next;
		public Node(T val) 
		{
			this.data=val;
		
		}
	}
	 public void MyStacklist()
	 {
		top=null; 
	 }
	 public boolean isEmpty()
	 {
		 return top==null;
	 }
	 //push
	 public void push(T val) 
	 {
		 Node newNode=new Node(val);
		 if(!isEmpty()) 
		 {
			newNode.next=top; 
		 }
		 top=newNode;
		 System.out.println("pushed:"+val);
	 }
	 
		//display data
		public void displayData() {
			Node temp=top;
			while(temp!=null) {
				System.out.print(temp.data+",");
				temp=temp.next;
			}
			System.out.println();
		}
		
		//pop
		public T pop()
		{
			if(!isEmpty())
			{
				Node temp=top;
				top=temp.next;
				temp.next=null;
				return temp.data;
				
			}
			System.out.println("stack is empty");
				return null;
		}
}
