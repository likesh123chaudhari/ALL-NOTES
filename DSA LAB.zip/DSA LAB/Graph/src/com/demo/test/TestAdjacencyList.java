package com.demo.test;

import com.demo.graphs.AdjacencyList;

public class TestAdjacencyList 
{

	public static void main(String[] args) 
	{
		AdjacencyList obj = new AdjacencyList(4);
		
		obj.addGraph();
		obj.displayData();
		obj.dfsTraversal(0);

	}

}
