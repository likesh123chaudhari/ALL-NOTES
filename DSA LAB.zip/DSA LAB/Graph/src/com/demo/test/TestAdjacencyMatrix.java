package com.demo.test;

import com.demo.graphs.AdjacencyMatrix;

public class TestAdjacencyMatrix 


{
	public static void main(String[] args) 
	{
		AdjacencyMatrix obj = new AdjacencyMatrix(4);
		obj.addGraph();
		obj.displayGraph();
	}
		
}
	

