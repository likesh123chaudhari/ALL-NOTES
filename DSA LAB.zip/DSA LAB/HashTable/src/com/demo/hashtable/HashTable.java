package com.demo.hashtable;

public class HashTable 
{

	Node[] heads;
	class Node
	{
		int data;
		Node next;
		
		public Node(int value)
		{
			this.data = value;
			this.next = null;
		}
	}	
	public HashTable()
	{
		heads = new Node[5];
	}
	
	public HashTable(int size)
	{
		heads = new Node[size];
	}
		
	//Insert the data in Nodes array
	public void insertData(int num)
	{
		Node newNode = new Node(num);
		
		//find the bucket number
		int pos = num % heads.length;
		
		//check if bucket is empty 
		if(heads[pos]==null)
		{
			heads[pos] = newNode;
		}
		else //if bucket is not empty then
		{
			newNode.next = heads[pos];
			heads[pos] = newNode;
		}
	}
	
	//search the element
	public boolean searchdata(int num)
	{
		//find the bucket number
		int pos = num % heads.length;
		
		//check if bucket is empty 
		if(heads[pos] == null)
		{
			System.out.println("Bucket is empty, Number is not found");
			return false;
		}
		
		else //if bucket is not empty then
		{
			Node temp = heads[pos];
			
			while(temp != null)
			{
				if(temp.data == num)
				{
					System.out.println(num + "is found " + "at position "+pos);
					return true;
				}
				else
				{
					temp = temp.next;
				}
			}
			System.out.println("number is not found "+num);
			return false;
		}
	
	}
	
	//display data
	public void displaydata()
	{
		for(int i=0; i<heads.length; i++)
		{
			Node temp = heads[i];
			System.out.print(i+ "---->");
			
			while(temp!= null)
			{
				System.out.print(temp.data+"----------");
				temp = temp.next;
			}
			System.out.print("null\n");
		}
	}
	
	
	}
