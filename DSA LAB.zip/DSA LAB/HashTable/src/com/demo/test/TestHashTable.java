package com.demo.test;

import com.demo.hashtable.HashTable;

public class TestHashTable 
{

	public static void main(String[] args) 
	{
		HashTable obj = new HashTable();
		
		obj.insertData(10);
		obj.insertData(20);
		obj.insertData(30);
		obj.insertData(40);
		obj.insertData(50);
		obj.insertData(30);
		obj.insertData(40);
		obj.insertData(50);
		
		
		obj.displaydata();
		

	}

}
