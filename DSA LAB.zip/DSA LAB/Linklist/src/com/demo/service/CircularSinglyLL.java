package com.demo.service;

public class CircularSinglyLL 
{
	Node head;
	class Node
	{
		int data; 
		Node next;
		
		public Node(int value)
		{
			this.data = value;
			this.next = null;
		}
	}
	
	//add Node
	public void addNode(int value)
	{
		Node newNode = new Node(value);
		if(head==null)
		{
			head = newNode;
			//newNode.next = head;
		}
		else
		{
			Node temp = head;
			while(temp.next!=head)
			{
				temp = temp.next;
			}
			temp.next = newNode;
		}
		newNode.next = head;
	}
	
	//display data
	
	public void displayData()
	{
		if(head == null)
		{
			System.out.println("List is empty");
		}
		else
		{
			Node temp = head;
			
			do {
				System.out.print(temp.data + " , ");
				temp = temp.next;
			}while(temp != head);
		}
		System.out.println();
	}
	
	//add by position
	public void addByPos(int value, int pos)
	{
		if(head == null)
		{
			System.out.println("List is empty");
		}
		else
		{
			Node newNode = new Node(value);
			//add node before first node
			if(pos == 1)
			{
				Node temp = head; 
				while(temp.next!=head) //we will place temp at last node upto head
				{
					temp = temp.next;
				} 
				newNode.next = head;
				head = newNode;
				temp.next = head;
			}
			else
			{
				Node temp = head;
				int count = 0;
				
				//add node in between
				for(int i=0; temp.next!=head && i<pos-2; i++)
				{
					temp = temp.next;
					count++;
				}
				if(count == pos-2)
				{
					newNode.next = temp.next;
					temp.next = newNode;
				}
				else
				{
					System.out.println("Position is out of bounds" +pos);
				}
			}
			
		}
	}
	
	//delete by position
	public void deleteByPos(int pos)
	{
		if(head == null)
		{
			System.out.println("List is empty");
		}
		else
		{
			Node temp = head;
			if(pos == 1)
			{
				while(temp.next!=head)
				{
					temp = temp.next;
				}
				temp.next = head.next;
				head.next=null;
				head = temp.next;
			}
			else
			{
				Node prev = null;
				int count = 0;
				for(int i=0; temp.next!=head && i<pos-1; i++)
				{
					prev = temp;
					temp = temp.next; 
					count++;
				}
				System.out.println("Count is : " +count);
				if(count == pos-1)
				{
					prev.next = temp.next;
					temp.next = null;
				}
				else
				{
					System.out.println("Position is out of bound" + pos);
				}
			}
		}
	}
	
	//add by value
	public void addByValue(int value, int num)
	{
		if(head == null)
		{
			System.out.println("List is empty");
		}
		else
		{
			Node newNode = new Node(value);
			
			Node temp = head;
			
			while(temp.next!=head && temp.data!=num)
			{
				temp = temp.next;
			}
			if(temp.data == num)
			{
				//adding the node after the number
				newNode.next = temp.next;
				temp.next = newNode;
			}
		}
	}
	
	//delete by value
	public void deleteByValue(int value)
	{
		if(head == null)
		{
			System.out.println("List is empty");
		}
		else
		{
			Node temp = head;
			
			//delete from the beginning
			if(temp.data == value)
			{
				head = temp.next;
				temp.next = null; 
			}
			else
			{
				Node prev = null;
				while(temp.next !=head && temp.data != value)
				{
					prev=temp;
					temp = temp.next;
				}
				if(temp.data == value)
				{
					prev.next = temp.next;
					temp.next = null;
				}
				else
				{
					System.out.println("Value not found");
				}
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
