package com.demo.service;

public class DoublyLL 
{
	Node head;
	class Node
	{
		int data;
		Node prev; 
		Node next;
		
		public Node(int data)
		{
			this.data = data;
			this.prev = null;
			this.next = null;
		}
	}
	
	//add node 
	public void addNode(int value)
	{
		//create a new node
		Node newNode = new Node(value);
		//add node at beginning
		if(head == null)
		{
			head = newNode;
		}
		else
		{
			Node temp = head;
			while(temp.next!= null)
			{
				temp = temp.next;
			}
			
			//add node at the end
			newNode.next = temp.next;
			newNode.prev = temp;
			temp.next = newNode;
		}
	}
	
	//display the data
	public void displayData()
	{
		if(head == null)
		{
			System.out.println("list is empty");
		}
		else
		{
			Node temp = head;
			while(temp!= null)
			{
				System.out.print(temp.data + " ,");
				temp = temp.next;
				
			}
			System.out.println();
		}
	}
	
	//add by value
	public void addByvalue(int value,int num)
	{
		if(head==null) 
		{
			System.out.println("list is empty");
		}
		else
		{
			Node newNode = new Node(value);
			
			if(head.data ==value)
			{
				newNode.next = head;
				head.prev = newNode;
				head = newNode;
			}
			else
			{
				Node temp = head;
				while(temp.next != null && temp.data!=num)
				{
					temp = temp.next;
				}
				if(temp.data == num)
				{
					newNode.next = temp.next;
					newNode.prev = temp;
					temp.next = newNode;
					
					if(temp.next!= null)
					{
						temp.next.prev = newNode;
					}
				}
			}
		}	
	}
	
	//add by position
	public void addByPos(int value, int pos)
	{
		if(head == null)
		{
			System.out.println("list is empty");
		}
		else
		{
			Node newNode = new Node(value);
			
			if(pos == 1)
			{
				newNode.next = head;
				head = newNode;
			}
			else
			{
				int count = 1;
				
				Node temp = head;
				for(int i=1; temp.next!=null && i<pos-1; i++)
				{
					temp = temp.next;
					count++;
				}
				System.out.println("count is:" +count);
				if(count == pos-1)
				{
					newNode.next = temp.next;
					newNode.prev = temp;
					temp.next = newNode;
				}
				else
				{
					System.out.println("position is out of bound" +pos);
				}
			}
		}
	}
	
	//delete by value
	public void deleteByvalue(int value) 
	{
		if(head==null) {
			System.out.println("list is empty");
		}
		else
		{
			Node temp = head;
			
			//delete node from head
			if(head.data == value)
			{
				head=temp.next;
				head.prev=null;
				temp.next=null;
			}
			else 
			{
				while(temp.next!=null && temp.data!=value)
				{
					temp=temp.next;
				}
				if(temp.data==value)
				{
					temp.next.prev=temp.next;
				
				if(temp.next!=null)
				{
					temp.next.prev=temp.prev;
				}
				temp.next=null;
				temp.prev=null;
				}
				else 
				{
					System.out.println("value is Not Found  "+value);
				}
			 }
			
			
		}
		
			
	 }
	///delete by pos 
	
	
		
	
	
}
