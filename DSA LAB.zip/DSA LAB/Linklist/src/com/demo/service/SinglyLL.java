package com.demo.service;

public class SinglyLL 
{
	Node head;
	
	class Node
	{
		int data; 
		Node next;
	
		public Node(int value)
		{
			this.data = value;
			this.next = null; 
		}
	}//node class ended
	
	
	//initiallize the SLL
	public SinglyLL()
	{
		this.head = null;
	}
	
	//add by position
	public void addByPosition(int value, int pos)
	{
		if(head == null)
		{
			System.out.println("List is empty");
		}
		else
		{
			//create a new node
			Node newNode = new Node(value);
			
			//add node at the beginning
			if(pos == 1)
			{
				newNode.next = head;
				head = newNode;
			}
			else
			{
				int count = 1;
				Node temp = head;
				for(int i=1; temp.next!= null && i<pos-1; i++)
				{
					temp = temp.next;
					count++;
				}
				System.out.println("count is : " +count);
				if(count== pos-1)
				{
					newNode.next = temp.next;
					temp.next = newNode;
				}
				else
				{
					System.out.println("Position is out of bounds");
				}
			}
				
		}
		
	
	}
	
	//add node at the end
	public void addNode(int value)
	{
		Node newNode = new Node(value);
		if(head == null)
		{
			head = newNode;
		}
		else
		{
			
			Node temp = head;
			while(temp.next!= null)
			{
				temp = temp.next;
			}
			temp.next = newNode;
		}
	}
	
//add by value after num
	public void addByValue(int value, int num)
	{
		if(head == null)
		{
			System.out.println("list is empty");
		}
		else
		{
			Node newNode = new Node(value);
			Node temp = head;
			while(temp.next!=null && temp.data!=num)
			{
				temp = temp.next;
			}
			if(temp.data == num)
			{
				newNode.next = temp.next;
				temp.next = newNode;
			}
			else
			{
				System.out.println("Number not found" +num);
			}
		}
	}
	
	
	
	//display the data
	public void displayData()
	{
		Node temp = head;
		
		while(temp != null)
		{
			System.out.print(temp.data + " , ");
			temp = temp.next;
		}
		System.out.println();
	}
	
	//delete by position 
	public int deleteByPos(int pos)
	{
		Node temp = head;
		
		//if pos is at beginning
		if(pos ==1)
		{
			head = temp.next;
			temp.next = null;
			return temp.data;
		}
		else
		{
			Node prev = null;
			//delete in between or at last pos
			int count=0;
			for(int  i=0; temp.next!=null && i<pos-1; i++)
			{
				prev = temp;
				temp = temp.next;
				count++;
			}
			System.out.println("count is : "+count);
			if(count == pos-1)
			{
				prev.next = temp.next;
				temp.next = null;
				return temp.data;
			}
			else
			{
				System.out.println("Position is out of bound" +pos);
				return -1;
			}
		}
	}
	
	//delete by value
	public void deleteByValue(int value)
	{
		Node temp = head;
		
		if(head.data == value)
		{
			head = temp.next;
			temp.next = null;
		}
		else
		{
			Node prev = null;
			
			while(temp.next!=null && temp.data!= value)
			{
				prev = temp;
				temp = temp.next;
			}
			if(temp.data  == value) 
			{
				prev.next = temp.next;
				temp.next = null;
				
			}
			else
			{
				System.out.println("Value not found");
			}
		}
	}
	
	
	public int findSum()
	{
		int sum = 0;
		
		Node temp = head;
		while(temp!= null)
		{
			sum = sum + temp.data;
			temp = temp.next;
			
		}
		return sum;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
