package com.demo.test;

import com.demo.service.CircularDoublyLL;

public class TestCircularDoublyLL 
{

	public static void main(String[] args) 
	{
		CircularDoublyLL cdlist = new CircularDoublyLL();
		
		cdlist.addNode(10);
		cdlist.addNode(20);
		cdlist.addNode(30);
		cdlist.addNode(40);
		cdlist.addNode(50);
		
		cdlist.displayData();
		
//		System.out.println("\n Reverse data is : " );
//		cdlist.displayDataRev();

		
//		cdlist.addByPos(20,2);
//		cdlist.displayData();
		System.out.println();
		cdlist.deleteByPos(5);
		cdlist.displayData();

	}

}
