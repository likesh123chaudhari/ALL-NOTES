package com.demo.test;

import com.demo.service.CircularSinglyLL;

public class TestCircularSinglyLL 
{

	public static void main(String[] args) 
	{
		CircularSinglyLL clist = new CircularSinglyLL();
		
		clist.addNode(10);
		clist.addNode(50);
		clist.addNode(20);
		clist.addNode(45);
		clist.addNode(30);
		clist.displayData();
		
		clist.addByPos(8, 1);
		clist.displayData();
		
		clist.addByValue(5, 10);
		clist.displayData();
		
		clist.deleteByValue(20);
		clist.displayData();
		
		System.out.println("=====================================");
		
		clist.deleteByPos(3);
		clist.displayData();
		
	}

}
