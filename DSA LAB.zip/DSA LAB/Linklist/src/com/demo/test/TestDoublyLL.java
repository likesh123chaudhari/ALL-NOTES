package com.demo.test;

import com.demo.service.DoublyLL;

public class TestDoublyLL 
{

	public static void main(String[] args)
	{
		DoublyLL dlist = new DoublyLL();
		
		dlist.addNode(10);
		dlist.addNode(20);
		dlist.addNode(30);
		dlist.addNode(40);
		dlist.addNode(50);
		
		dlist.displayData();
		
		dlist.addByvalue(9,50);
		dlist.displayData();
		
		System.out.println("===============================");
		dlist.addByPos(8, 4);
		dlist.displayData();
		
		System.out.println("===============================");
		dlist.deleteByvalue(50);
		dlist.displayData();
	}

}
