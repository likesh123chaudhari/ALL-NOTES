package com.demo.test;

import com.demo.service.SinglyLL;

public class TestSinglyLL {

	public static void main(String[] args) 
	{
		SinglyLL slist = new SinglyLL();
		
		slist.addNode(12);
		slist.addNode(15);
		slist.addNode(10);
		slist.addNode(7);
		slist.addNode(5);
		slist.displayData();
		
		slist.addByPosition(80, 3);
		slist.displayData();
		
//		slist.addByValue(23, 15);
//		slist.displayData();
		
		slist.deleteByPos(2);
		slist.displayData();
		
		System.out.println("----------------------------");
		slist.deleteByValue(7);
		slist.displayData();
		
		int s = slist.findSum();
		System.out.println("sum is : "+s);
		//slist.displayData();
	}
}
