package com.demo.service;

import java.util.Arrays;


public class HeapSortService 
{
	
	//Max Heap
//	public static void heapify(int[] arr,int n,int i) 
//	{
//		
//		int left=2*i+1;
//		int right=2*i+2;
//		int largest=i;
//		
//		//is left child value >parent value
//		if(left<n && arr[left]>arr[largest])
//		{
//			largest = left;
//			//System.out.println("largest is at left side" + Arrays.toString(arr));
//			
//		}
//		if(right<n && arr[right]>arr[largest])
//		{
//			largest = right;
//		}
//		if(largest != i)
//		{
//			//swap largest & i 
//			int temp = arr[largest];
//			arr[largest] = arr[i];
//			arr[i] = temp;
//			
//			System.out.println("swap largest element =" +arr[largest] +" and i = " +arr[i]);
//			System.out.println(Arrays.toString(arr));
//			System.out.println("------------------------------------");
//			heapify(arr, n, largest);
//		}
//		
//	}
//	
//	
//	public static void heapSortAsc(int[] arr)
//	{
//		//convert the tree into max heap
//		for(int i=(arr.length/2)-1; i>=0; i--)
//		{
//			heapify(arr, arr.length, i);
//			System.out.println("convert the tree into max heap");
//			System.out.println(Arrays.toString(arr));
//		}
//		
//		
//		int n = arr.length;
//		
//		//sort the array
//		for(int i=n-1; i>=0; i--)
//		{
//			//swap first element with last element
//			int temp = arr[0];
//			arr[0] = arr[i];
//			arr[i] = temp;
//			
//			System.out.println("swap first element =" +arr[0] +" with last element = " +arr[i]);
//			System.out.println(Arrays.toString(arr));
//			System.out.println("================================");
//			
//			//adjust the tree with root 0
//			heapify(arr, i ,0);
//		}
//	}
//	
	
		//Min Heap
		public static void heapifyMin(int[] arr,int n, int i) 
		{
//			int[] arr = {7,10,5,12,3,9,2,1};
			int left=2*i+1;
			int right=2*i+2;
			int smallest=i;
			
			//if left child value <parent value
			if(left<n && arr[left]<arr[smallest])
			{
				smallest=left;
			}
			if(right<n && arr[right]<arr[smallest])
			{
				smallest=right;
			}
			
			
			if(smallest!=i)
			{
				//swap the  smallest element and i
				
				int temp=arr[smallest];
				arr[smallest]=arr[i];
				arr[i]=temp;
				//System.out.println(Arrays.toString(arr));
				heapifyMin(arr,n, smallest);
			}
			
		}
		
		public static void heapSortDesc(int[] arr)
		{
			for (int i=(arr.length/2)-1; i>=0; i--) 
			{
				heapifyMin(arr, arr.length,i);
					  
			}
			int n=arr.length;
			
			//sort the array 
			for (int i=n-1 ;i>=0;i--)
			{
				int temp=arr[0];
				arr[0]=arr[i];
				arr[i]=temp;
				System.out.println(Arrays.toString(arr));
				heapifyMin(arr, i, 0);
				System.out.println("swap first element =" +arr[0] +" with last element = " +arr[i]);
				System.out.println(Arrays.toString(arr));
				System.out.println("================================");
			}
		}
		
	
	
	}
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


