package com.demo.StackQueue;

public class MyQueueList
{
        Node front ,rear;
        class Node
        {
        	int data;
        	Node Next;
        	public Node(int value)
        	{
        		this.data=value;
        		this.Next=null;
        	}
        	
      	}
        public MyQueueList()
        {
        	front=null;
        	rear=null;
        }
        public boolean isEmpty()
        {
        	if(front==null) 
        	{
        		System.out.println("queue is empty");
        		return true;
        	}
        	return false;
        	
        }
        //enqueue 
        //it will add at rear end
        public void enqueue(int val)
        {
        
        	Node newNode= new Node(val);
        	//it    checking
        	if(isEmpty())
        	{
        		rear=newNode;
        		front=newNode;
        	}
        	else
        	{
        		rear.Next=newNode;
        		front=newNode;
        	}
        	System.out.println("added  sucessfully");
        	
        }
        //dequeue
       // it remove from the first
        public int dequeue() 
        {
        	if(isEmpty()) //we are check queue empty or not
        	{
        		System.out.println("queue is empty");
        		return -1;
        	}
        	else
        	{
        		Node temp=front;
        		int num=front.data;
        		front=front.Next;
        		temp.Next=null;
        	   return num;	
        	}
			
        }
        
        
        // display the data 
        public void displayData()
        {
       
         Node temp=front;
         while(temp!=null) 
         {
        	 System.out.print(temp.data);
        	 temp=temp.Next;
        	 
         }
         System.out.println();
        
        
        }
        
        
}















