package com.demo.StackQueue;


public class MyStackGeneric <T> {
	Node top;
	class Node
	{
		T data;
		Node next;
		
		public Node(T value) 
		{
			this.data=value;
		}
		
	}
	public MyStackGeneric()
	{
		top=null;
	}
	public boolean  isEmpty()
	//it is check the condition
	{
		return top==null;
		
	}
	//push 
	public void push(T value) 
	{
		Node newNode=new Node(value);
         
		if(!isEmpty()) 
		{
			newNode.next=top;
		}
		top=newNode;
		System.out.println("pushed the value"+value);
	}
	
	// Display the data 
	public void displayData()
	{
		Node temp=top;
		while (temp!=null) 
		{
			System.out.println(temp.data);
			temp=temp.next;
			
		}
	}
	
	//pop
    public T pop()
	{
		if(!isEmpty())
		{
			Node temp=top;
			top=temp.next;
			temp.next=null;
			return temp.data;
		   	
		}
		System.out.println("Stack is empty");
		return null;
		
	}



}
