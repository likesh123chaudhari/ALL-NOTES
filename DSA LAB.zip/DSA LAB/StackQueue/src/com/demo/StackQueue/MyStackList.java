package com.demo.StackQueue;

public class MyStackList {
	
	Node top;
	class Node
	{
		int data;
		Node next;
		
		public Node(int value) 
		{
			this.data=value;
		}
		
	}
	public MyStackList()
	{
		top=null;
	}
	public boolean  isEmpty()
	//it is check the condition
	{
		return top==null;
		
	}
	//push 
	public void push(int value) 
	{
		Node newNode=new Node(value);
         
		if(!isEmpty()) 
		{
			newNode.next=top;
		}
		top=newNode;
		System.out.println("pushed the value"+value);
	}
	
	// Display the data 
	public void displayData()
	{
		Node temp=top;
		while (temp!=null) 
		{
			System.out.println(temp.data);
			temp=temp.next;
			
		}
	}
	
	//pop
    public int pop()
	{
		if(!isEmpty())
		{
			Node temp=top;
			top=temp.next;
			temp.next=null;
			return temp.data;
		   	
		}
		System.out.println("Stack is empty");
		return -1;
		
	}
}
