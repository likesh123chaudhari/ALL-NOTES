package com.demo.StackQueue;

public class StackGeneric<T> 
{
	Node top;
	class Node
	{
		T data;
		Node next;
		public Node(T value)
		{
			this.data = value;
		}
	}
	
	public StackGeneric()
	{
		top = null;
	}
	
	public boolean isEmpty()
	{
		return top == null;
	}
	
	public void push(T value)
	{
		Node newNode = new Node(value);
		
		if(!isEmpty())
		{
			newNode.next = top;
		}
		top = newNode;
		//System.out.println("Pushed element is : "+value);
	}
	
	public T pop()
	{
		if(!isEmpty())
		{
			Node temp = top;
			top = temp.next;
			temp.next = null;
			return temp.data;
		}
		System.out.println("Stack is empty");
		return null;
	}
	
	public void displayData()
	{
		Node temp = top;
		
		while(temp != null)
		{
			System.out.println(temp.data);
			temp = temp.next;
		}
	}	
	
}
