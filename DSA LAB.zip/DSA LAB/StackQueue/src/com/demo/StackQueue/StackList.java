package com.demo.StackQueue;

public class StackList 
{
	Node top;
	class Node
	{
		int data;
		Node next;
		public Node(int value)
		{
			this.data = value;
		}
	}
	public StackList()
	{
		top = null;
	}
	public boolean isEmpty()
	{
		return top == null;
	}
	public void push(int value)
	{
		Node newNode = new Node(value);
		
		if(!isEmpty())
		{
			newNode.next = top;
		}
		top = newNode;
		System.out.println("Pushed element is : "+value);
	}
	public void displayData()
	{
		Node temp = top;
		
		while(temp!=null)
		{
			temp = temp.next;
		}
	}
	
	public void pop(int value)
	{
		if(!isEmpty())
		{
			Node temp = top;
			top = temp.next;
			temp.next = null;
			System.out.println("popped element is : "+value);
		}
		else
		{
			System.out.println("Stack is empty");
		}
	}
	
	
	
}
