package com.demo.test;

import com.demo.StackQueue.CircularQueue;

public class TestCircularQueue 
{
	public static void main(String[] args) 
	{
		CircularQueue obj = new CircularQueue();
		
		obj.enqueue(10);
		obj.enqueue(20);
		obj.enqueue(30);
		obj.enqueue(40);
		obj.enqueue(50);
		
		//Queue is full
		obj.enqueue(10);
		obj.enqueue(20);
		obj.enqueue(30);
		
		System.out.println("==================================");
		
//		System.out.println(obj.dequeue());
//		System.out.println(obj.dequeue());
//		System.out.println(obj.dequeue());
//		System.out.println(obj.dequeue());
//		System.out.println(obj.dequeue());
		//System.out.println(obj.dequeue());
		
		while(!obj.isEmpty())
		{
			System.out.print("dequeue" +obj.dequeue()+",");
		}
		System.out.println();
	}

}
