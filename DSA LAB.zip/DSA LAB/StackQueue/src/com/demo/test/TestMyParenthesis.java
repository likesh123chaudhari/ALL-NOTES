package com.demo.test;

import com.demo.StackQueue.MyStackGeneric;

public class TestMyParenthesis {

	public static void main(String[] args) {
	
		String str1= "{({{[()]})}";
		boolean status=checkParenthesis(str1);
		if(status) {
			System.out.println("It is balanced parenthesis "+str1);
		}
		else
		{
			System.out.println("It is not balanced");
		}
    
	}
	 private static boolean checkParenthesis(String str)
     {
		 MyStackGeneric<Character> st= new MyStackGeneric<>();
		 for(int i=0;i<str.length();i++)
		 
		 {
			 Character ch=str.charAt(i);
			 if(ch=='('||ch=='{'||ch=='[')
			 {
				st.push(ch); 
			 }
			 else 
			 {
				if(st.isEmpty())
				{
					return false;
				}
				else
				 {
					 Character ch1=st.pop();
					 switch(ch) 
					 {
					 
					     case '}':
						 if(ch!='{')
						 return false;
						 break;
						 
					     case ']':
						 if(ch!='[')
						 return false;
						break;
					     case ')':
							 if(ch!='(')
							 return false;
							 break;
							 
					}
					
				
				}
			 }
		  }// end of   for
			 
			 if(st.isEmpty())
			 {
				return true; 
			 }
			 else 
			 {
				 return false;
			 }
    	 
       }
}
