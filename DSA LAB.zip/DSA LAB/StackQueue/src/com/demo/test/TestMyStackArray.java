package com.demo.test;

import com.demo.StackQueue.MyStackArray;

public class TestMyStackArray 
{
	public static void main(String[] args) 
	{
		MyStackArray mlist= new MyStackArray();
		mlist.push(10);
		mlist.push(20);
		mlist.push(30);
		mlist.push(40);
		while(!mlist.isEmpty()) 
		{
		   System.out.println(mlist.pop());	
		}
	}

	
	}


