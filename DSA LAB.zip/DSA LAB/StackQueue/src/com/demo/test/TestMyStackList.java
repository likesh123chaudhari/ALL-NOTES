package com.demo.test;

import com.demo.StackQueue.MyStackList;

public class TestMyStackList {
	public static void main(String[] args) {
		MyStackList mlist= new MyStackList();
		mlist.push(10);
		mlist.push(20);
		mlist.push(30);
		mlist.push(40);
		System.out.println(mlist.pop());
		System.out.println(mlist.pop());
		System.out.println(mlist.pop());
		System.out.println(mlist.pop());
		System.out.println(mlist.pop());
	}

}
