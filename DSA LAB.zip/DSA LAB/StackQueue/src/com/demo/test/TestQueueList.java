package com.demo.test;

import java.util.Arrays;

import com.demo.StackQueue.MyQueueList;

public class TestQueueList {

	public static void main(String[] args) {
		MyQueueList ob=new MyQueueList();
		// added
		System.out.println("---------------------");
		ob.enqueue(10);
		ob.displayData();
		ob.enqueue(20);
		ob.displayData();
		ob.enqueue(30);
		ob.displayData();
		ob.enqueue(40);
		ob.displayData();
		ob.enqueue(50);
		ob.displayData();
		System.out.println("---------------------");
		// delete Dequeue
			while(!ob.isEmpty())
		{
			System.out.println(ob.dequeue());
			ob.displayData();
			
			System.out.println("---------------------");
			System.out.println(ob.dequeue());
			ob.displayData();
		
			
		}
		
	}
}
