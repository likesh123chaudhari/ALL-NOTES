package com.demo.test;

import com.demo.StackQueue.QueueList;

public class TestQueueList1 
{

	public static void main(String[] args) 
	{
		QueueList obj = new QueueList();
		
		obj.enqueue(10);
		obj.enqueue(20);
		obj.enqueue(30);
		obj.enqueue(40);

		obj.displayData();
		
		System.out.println("dequeue "+ obj.dequeue());
		System.out.println("dequeue "+ obj.dequeue());
		System.out.println("dequeue "+ obj.dequeue());
		
		
		while(!obj.isEmpty()) 
		{
			System.out.println("dequeue " + obj.dequeue());
		}
	}

}
