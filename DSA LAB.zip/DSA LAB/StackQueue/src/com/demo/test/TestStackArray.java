package com.demo.test;

import com.demo.StackQueue.StackArray;

public class TestStackArray 
{

	public static void main(String[] args) 
	{
		StackArray alist = new StackArray();
		
		alist.push(10);
		alist.push(20);
		alist.push(30);
		alist.push(40);
		alist.push(50);
		
		
		while(!alist.isEmpty())
		{
			System.out.println(alist.pop());
		}

	}

}
