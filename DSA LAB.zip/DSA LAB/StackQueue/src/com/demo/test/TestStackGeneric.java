package com.demo.test;

import java.util.Arrays;
import java.util.Scanner;

import com.demo.StackQueue.MyStackGeneric;

public class TestStackGeneric
{
	public static void main(String[] args) 
	{
		//to print integer
		MyStackGeneric<Integer> ob=new MyStackGeneric<>();
		 ob.push(10);
		 ob.push(20);
		 ob.push(30);
		 ob.push(40);
		 ob.push(50);
		 System.out.println(ob.pop());
		 System.out.println(ob.pop());
		 System.out.println(ob.pop());
		 System.out.println(ob.pop());
		 System.out.println(ob.pop());
		 
		 /// to print string 
			MyStackGeneric<String> ob1=new MyStackGeneric<>();
			ob1.push("hello");
			ob1.push("gutan morgan");
			ob1.push("chuss");
			ob1.push("good bye");
			
			//to print Reverse string 
			Scanner sc=new Scanner(System.in);
			String s=sc.nextLine();
			String [] carr=s.split("");
			MyStackGeneric<String> ob2=new MyStackGeneric<>();
			System.out.println(Arrays.toString(carr));
			
			for (int i=0;i<carr.length;i++)
			{
				ob2.push(carr[i]);
				
			}
			while(!ob2.isEmpty()){
				System.out.println(ob2.pop());
				
			}
			
			
	}
	
	
	
}
