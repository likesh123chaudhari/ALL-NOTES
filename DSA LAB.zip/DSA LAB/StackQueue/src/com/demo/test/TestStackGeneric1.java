package com.demo.test;

import com.demo.StackQueue.StackGeneric;

public class TestStackGeneric1 
{

	public static void main(String[] args) 
	{
		StackGeneric<Integer> slist = new StackGeneric<>();
		
		slist.push(10);
		slist.push(20);
		slist.push(30);
		slist.push(40);
		
		slist.displayData();
		System.out.println("popped element is : "+slist.pop());
		
		System.out.println("===========================================");

		StackGeneric<String> glist = new StackGeneric<>();
		
		glist.push("Hello");
		glist.push("Good morning");
		glist.push("Everyone");
		glist.push("Have a nice day!!");
		
		glist.displayData();
		System.out.println("popped element is : "+glist.pop());
		
	}

}
