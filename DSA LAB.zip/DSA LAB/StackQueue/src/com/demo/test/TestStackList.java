package com.demo.test;

import com.demo.StackQueue.StackList;

public class TestStackList 
{

	public static void main(String[] args) 
	{
		StackList slist = new StackList();
		
		slist.push(10);
		slist.push(20);
		slist.push(30);
		slist.push(40);
		slist.push(50);
		
		slist.displayData();
		
		System.out.println("------------------------------------");
		
		slist.pop(20);
		slist.pop(10);
		
		slist.displayData();
	}

}
