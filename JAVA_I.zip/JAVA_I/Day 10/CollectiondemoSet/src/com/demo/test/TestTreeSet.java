package com.demo.test;

import java.util.Set;
import java.util.TreeSet;

public class TestTreeSet {

	public static void main(String[] args) {
		Set<Integer> ts=new TreeSet<>();
		ts.add(30);
		ts.add(40);
		ts.add(12);
		System.out.println(ts);

	}

}
